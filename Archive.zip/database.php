<?php
//$hn = "localhost";
//$db = "ms_login";
//$un = "msaha";
//$pw = "L9cSMtnXUw25L7aA";
$hn = "localhost";
$db = "final";
$un = "root";
$pw = "";

//$hn = "earth.cs.utep.edu";
//$db = "wb_msaha";
//$un = "wb_msaha";
//$pw = "BI2%%800nsa*(*(!";

?>
